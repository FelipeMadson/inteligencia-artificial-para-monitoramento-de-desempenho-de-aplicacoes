# Inteligência Artificial para Monitoramento de Desempenho de Aplicações

[![CI Status](https://github.com/FelipeMadson/inteligencia-artificial-para-monitoramento-de-desempenho-de-aplicacoes/actions/workflows/ci.yml/badge.svg)](https://github.com/FelipeMadson/inteligencia-artificial-para-monitoramento-de-desempenho-de-aplicacoes/actions)
[![Latest Release](https://img.shields.io/github/v/release/FelipeMadson/inteligencia-artificial-para-monitoramento-de-desempenho-de-aplicacoes?color=145e4d&logo=github)](https://github.com/FelipeMadson/inteligencia-artificial-para-monitoramento-de-desempenho-de-aplicacoes/releases)
[![Conventional Commits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-yellow.svg)](https://conventionalcommits.org)
[![SemVer 2.0.0](https://img.shields.io/badge/semver-2.0.0-blue.svg)](https://semver.org)

[![CI Status](https://github.com/FelipeMadson/inteligencia-artificial-para-monitoramento-de-desempenho-de-aplicacoes/actions/workflows/ci.yml/badge.svg)](https://github.com/FelipeMadson/inteligencia-artificial-para-monitoramento-de-desempenho-de-aplicacoes/actions)
[![Latest Release](https://img.shields.io/github/v/release/FelipeMadson/inteligencia-artificial-para-monitoramento-de-desempenho-de-aplicacoes?color=145e4d&logo=github)](https://github.com/FelipeMadson/inteligencia-artificial-para-monitoramento-de-desempenho-de-aplicacoes/releases)
[![Conventional Commits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-yellow.svg)](https://conventionalcommits.org)
[![SemVer 2.0.0](https://img.shields.io/badge/semver-2.0.0-blue.svg)](https://semver.org)

![Java](https://img.shields.io/badge/Java-17%2B-blue)
![Maven](https://img.shields.io/badge/Maven-Build-success)
![License](https://img.shields.io/badge/license-MIT-green)

## Problem Statement
Monitoramento em tempo real de desempenho de aplicações web e microservices

## Architecture
Standard Maven project layout with domain logic for hashing and state management.

## Install & Run
```bash
mvn clean install
```

## License
MIT License

## Author
Felipe Madson

---

## 🖥️ Demonstração em Terminal Vetorial (Execução & Benchmarks)

<p align="center">
  <img src="docs/assets/terminal-demo.svg" alt="Terminal Demo - Inteligencia Artificial Para Monitoramento De Desempenho De Aplicacoes" width="840" />
</p>

---

## 📦 Polyglot Client SDKs (TypeScript & Python)

SDKs tipados com zero dependências externas em `sdk/`:

```typescript
import { inteligenciaartificialparamonitoramentodedesempenhodeaplicacoesClient } from "./sdk/ts/client.ts";
const client = new inteligenciaartificialparamonitoramentodedesempenhodeaplicacoesClient({ baseUrl: "http://127.0.0.1:3000" });
const health = await client.checkHealth();
console.log("Health:", health.status);
```
